Modernizr.load({
	test: Modernizr.canvas,
	nope:'http://flashcanvas.net/bin/flashcanvas.js'
});